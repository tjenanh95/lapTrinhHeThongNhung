/*
 * uart_0_util.h
 *
 *  Created on: Feb 27, 2019
 *      Author: BaTien
 */

#ifndef UART_0_UTIL_H_
#define UART_0_UTIL_H_



void Putstr(char *str);



#endif /* UART_0_UTIL_H_ */
